package JAVAMODBUSTCP;

import java.awt.Font;

public final class Main extends javax.swing.JFrame {

    public Main() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.jTabbedPaneMiddle.setFont(new Font("Ariel", Font.BOLD, 14));
        this.pack();
        EnableDisableLocalAddress();         
    }

    public static void SetClientAddress() {
        ModbusClient.SetLocalIP(localSpinner1.getValue().toString() + "." + localSpinner2.getValue().toString() + "." + localSpinner3.getValue().toString() + "." + localSpinner4.getValue().toString());        
        ModbusClient.SetRemoteIP(remoteSpinner1.getValue().toString() + "." + remoteSpinner2.getValue().toString() + "." + remoteSpinner3.getValue().toString() + "." + remoteSpinner4.getValue().toString());
        ModbusClient.SetRemotePortNumber((int) portSpinner.getValue());
        ModbusClient.SetBound(bindLocal.isSelected());   
    }

    public static void SetRequest(String request) {
        requestTextField.setText(request);
        exceptionTextField.setText("");
    }

    public static void SetResponse(String response) {
        responseTextField.setText(response);
    }

    public static void SetException(String request) {
        exceptionTextField.setText(request);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        bindButton = new javax.swing.JPanel();
        portLabel = new javax.swing.JLabel();
        portSpinner = new javax.swing.JSpinner();
        remoteSpinner2 = new javax.swing.JSpinner();
        remoteSpinner3 = new javax.swing.JSpinner();
        remoteSpinner4 = new javax.swing.JSpinner();
        remoteAddressLabel = new javax.swing.JLabel();
        remoteSpinner1 = new javax.swing.JSpinner();
        localSpinner1 = new javax.swing.JSpinner();
        localSpinner2 = new javax.swing.JSpinner();
        localSpinner3 = new javax.swing.JSpinner();
        localSpinner4 = new javax.swing.JSpinner();
        bindLocal = new javax.swing.JCheckBox();
        jTabbedPaneMiddle = new javax.swing.JTabbedPane();
        readCoilPanel = new JAVAMODBUSTCP.ReadCoilPanel();
        readHoldingRegisterPanel = new JAVAMODBUSTCP.ReadHoldingRegisterPanel();
        writeSingleCoilPanel = new JAVAMODBUSTCP.WriteSingleCoilPanel();
        writeSingleRegisterPanel = new JAVAMODBUSTCP.WriteSingleRegisterPanel();
        writeMultipleCoilPanel = new JAVAMODBUSTCP.WriteMultipleCoilsPanel();
        writeMultipleRegisterPanel = new JAVAMODBUSTCP.WriteMultipleRegisterPanel();
        writeFloatingPointPanel1 = new JAVAMODBUSTCP.WriteFloatingPointPanel();
        jPanelBottom = new javax.swing.JPanel();
        requestLabel = new javax.swing.JLabel();
        requestTextField = new javax.swing.JTextField();
        responseLabel = new javax.swing.JLabel();
        responseTextField = new javax.swing.JTextField();
        exceptionLabel = new javax.swing.JLabel();
        exceptionTextField = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("MODBUS TCP UTILITY by W.D.F.");
        setLocation(new java.awt.Point(0, 0));
        setName("Main Frame"); // NOI18N
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        getContentPane().setLayout(new java.awt.GridBagLayout());

        bindButton.setLayout(new java.awt.GridBagLayout());

        portLabel.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        portLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        portLabel.setText("PORT");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        bindButton.add(portLabel, gridBagConstraints);

        portSpinner.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        portSpinner.setModel(new javax.swing.SpinnerNumberModel(502, 0, 10000, 1));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHEAST;
        bindButton.add(portSpinner, gridBagConstraints);

        remoteSpinner2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        remoteSpinner2.setModel(new javax.swing.SpinnerNumberModel(168, 0, 255, 1));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        bindButton.add(remoteSpinner2, gridBagConstraints);

        remoteSpinner3.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        remoteSpinner3.setModel(new javax.swing.SpinnerNumberModel(0, 0, 255, 1));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        bindButton.add(remoteSpinner3, gridBagConstraints);

        remoteSpinner4.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        remoteSpinner4.setModel(new javax.swing.SpinnerNumberModel(236, 0, 255, 1));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        bindButton.add(remoteSpinner4, gridBagConstraints);

        remoteAddressLabel.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        remoteAddressLabel.setText("REMOTE ETHERNET ADDRESS");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        bindButton.add(remoteAddressLabel, gridBagConstraints);

        remoteSpinner1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        remoteSpinner1.setModel(new javax.swing.SpinnerNumberModel(192, 0, 255, 1));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        bindButton.add(remoteSpinner1, gridBagConstraints);

        localSpinner1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        localSpinner1.setModel(new javax.swing.SpinnerNumberModel(192, 0, 255, 1));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        bindButton.add(localSpinner1, gridBagConstraints);

        localSpinner2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        localSpinner2.setModel(new javax.swing.SpinnerNumberModel(168, 0, 255, 1));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        bindButton.add(localSpinner2, gridBagConstraints);

        localSpinner3.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        localSpinner3.setModel(new javax.swing.SpinnerNumberModel(1, 0, 255, 1));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        bindButton.add(localSpinner3, gridBagConstraints);

        localSpinner4.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        localSpinner4.setModel(new javax.swing.SpinnerNumberModel(2, 0, 255, 1));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        bindButton.add(localSpinner4, gridBagConstraints);

        bindLocal.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        bindLocal.setText("BIND LOCAL ETHERNET ADDRESS");
        bindLocal.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        bindLocal.setMargin(new java.awt.Insets(0, 0, 0, 0));
        bindLocal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bindLocalActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.SOUTHWEST;
        bindButton.add(bindLocal, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        getContentPane().add(bindButton, gridBagConstraints);

        jTabbedPaneMiddle.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "MODBUS FUNCTION CODE", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 14))); // NOI18N
        jTabbedPaneMiddle.setToolTipText("MODBUS FUNCTION CODE");
        jTabbedPaneMiddle.addTab("01/02", readCoilPanel);
        jTabbedPaneMiddle.addTab("03/04", readHoldingRegisterPanel);
        jTabbedPaneMiddle.addTab("05", writeSingleCoilPanel);
        jTabbedPaneMiddle.addTab("06", writeSingleRegisterPanel);
        jTabbedPaneMiddle.addTab("15", writeMultipleCoilPanel);
        jTabbedPaneMiddle.addTab("16", writeMultipleRegisterPanel);
        jTabbedPaneMiddle.addTab("99", writeFloatingPointPanel1);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(10, 0, 10, 0);
        getContentPane().add(jTabbedPaneMiddle, gridBagConstraints);

        jPanelBottom.setLayout(new java.awt.GridLayout(6, 1));

        requestLabel.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        requestLabel.setText("REQUEST BYTE ARRAY");
        jPanelBottom.add(requestLabel);

        requestTextField.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jPanelBottom.add(requestTextField);

        responseLabel.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        responseLabel.setText("RESPONSE BYTE ARRAY");
        jPanelBottom.add(responseLabel);

        responseTextField.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jPanelBottom.add(responseTextField);

        exceptionLabel.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        exceptionLabel.setText("EXCEPTION");
        jPanelBottom.add(exceptionLabel);

        exceptionTextField.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jPanelBottom.add(exceptionTextField);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.ipadx = 250;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        getContentPane().add(jPanelBottom, gridBagConstraints);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        ModbusClient.Disconnect();
    }//GEN-LAST:event_formWindowClosing

    private void bindLocalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bindLocalActionPerformed
        EnableDisableLocalAddress();             
    }//GEN-LAST:event_bindLocalActionPerformed

    private static void EnableDisableLocalAddress(){
        localSpinner1.setEnabled(bindLocal.isSelected());
        localSpinner2.setEnabled(bindLocal.isSelected());
        localSpinner3.setEnabled(bindLocal.isSelected());
        localSpinner4.setEnabled(bindLocal.isSelected());         
    }
    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Main().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel bindButton;
    private static javax.swing.JCheckBox bindLocal;
    private javax.swing.JLabel exceptionLabel;
    private static javax.swing.JTextField exceptionTextField;
    private javax.swing.JPanel jPanelBottom;
    private javax.swing.JTabbedPane jTabbedPaneMiddle;
    private static javax.swing.JSpinner localSpinner1;
    private static javax.swing.JSpinner localSpinner2;
    private static javax.swing.JSpinner localSpinner3;
    private static javax.swing.JSpinner localSpinner4;
    private javax.swing.JLabel portLabel;
    private static javax.swing.JSpinner portSpinner;
    private JAVAMODBUSTCP.ReadCoilPanel readCoilPanel;
    private JAVAMODBUSTCP.ReadHoldingRegisterPanel readHoldingRegisterPanel;
    private javax.swing.JLabel remoteAddressLabel;
    private static javax.swing.JSpinner remoteSpinner1;
    private static javax.swing.JSpinner remoteSpinner2;
    private static javax.swing.JSpinner remoteSpinner3;
    private static javax.swing.JSpinner remoteSpinner4;
    private javax.swing.JLabel requestLabel;
    private static javax.swing.JTextField requestTextField;
    private javax.swing.JLabel responseLabel;
    private static javax.swing.JTextField responseTextField;
    private JAVAMODBUSTCP.WriteFloatingPointPanel writeFloatingPointPanel1;
    private JAVAMODBUSTCP.WriteMultipleCoilsPanel writeMultipleCoilPanel;
    private JAVAMODBUSTCP.WriteMultipleRegisterPanel writeMultipleRegisterPanel;
    private JAVAMODBUSTCP.WriteSingleCoilPanel writeSingleCoilPanel;
    private JAVAMODBUSTCP.WriteSingleRegisterPanel writeSingleRegisterPanel;
    // End of variables declaration//GEN-END:variables
}
