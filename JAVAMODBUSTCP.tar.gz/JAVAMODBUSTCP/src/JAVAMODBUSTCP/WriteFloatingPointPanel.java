package JAVAMODBUSTCP;

public class WriteFloatingPointPanel extends javax.swing.JPanel {
    
    public WriteFloatingPointPanel() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        floatingPointValueLabel = new javax.swing.JLabel();
        floatingPointTextField = new javax.swing.JTextField();
        registerLabel0 = new javax.swing.JLabel();
        writeFloatingPointValue = new javax.swing.JButton();
        registerTextField1 = new javax.swing.JTextField();
        addressTextField = new javax.swing.JTextField();
        registerLabel1 = new javax.swing.JLabel();
        addressLabel = new javax.swing.JLabel();
        registerTextField0 = new javax.swing.JTextField();

        setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.gray, 5));
        setLayout(new java.awt.GridBagLayout());

        floatingPointValueLabel.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        floatingPointValueLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        floatingPointValueLabel.setText("FLOATING POINT VALUE");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        add(floatingPointValueLabel, gridBagConstraints);

        floatingPointTextField.setColumns(1);
        floatingPointTextField.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        floatingPointTextField.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        floatingPointTextField.setText("0");
        floatingPointTextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.ipadx = 75;
        gridBagConstraints.ipady = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(floatingPointTextField, gridBagConstraints);

        registerLabel0.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        registerLabel0.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        registerLabel0.setText("REGISTER[ADDRESS]");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        add(registerLabel0, gridBagConstraints);

        writeFloatingPointValue.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        writeFloatingPointValue.setText("WRITE FLOATING POINT");
        writeFloatingPointValue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                writeFloatingPointValueActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        add(writeFloatingPointValue, gridBagConstraints);

        registerTextField1.setEditable(false);
        registerTextField1.setColumns(1);
        registerTextField1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        registerTextField1.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        registerTextField1.setText(" ");
        registerTextField1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.ipadx = 60;
        gridBagConstraints.ipady = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(registerTextField1, gridBagConstraints);

        addressTextField.setColumns(1);
        addressTextField.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        addressTextField.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        addressTextField.setText("1");
        addressTextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.ipadx = 75;
        gridBagConstraints.ipady = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(addressTextField, gridBagConstraints);

        registerLabel1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        registerLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        registerLabel1.setText("REGISTER[ADDRESS+1]");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 7;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        add(registerLabel1, gridBagConstraints);

        addressLabel.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        addressLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        addressLabel.setText("ADDRESS");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        add(addressLabel, gridBagConstraints);

        registerTextField0.setEditable(false);
        registerTextField0.setColumns(1);
        registerTextField0.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        registerTextField0.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        registerTextField0.setText(" ");
        registerTextField0.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.ipadx = 60;
        gridBagConstraints.ipady = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(registerTextField0, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents

    private void writeFloatingPointValueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_writeFloatingPointValueActionPerformed
        Main.SetClientAddress();

        ModbusClient.Connect();
        short[] registers = new short[2];
        int intBits = Float.floatToIntBits(Float.parseFloat(floatingPointTextField.getText()));
        registers[1]= (short)(intBits >> 16);
        registers[0]= (short)(intBits & 0xFFFF);
        
        registerTextField0.setText(Integer.toString(registers[0]));
        registerTextField1.setText(Integer.toString(registers[1]));
        
        ModbusCommand.WriteMultipleRegister(Short.parseShort(addressTextField.getText()), registers);
        ModbusClient.Disconnect();
    }//GEN-LAST:event_writeFloatingPointValueActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel addressLabel;
    private javax.swing.JTextField addressTextField;
    private javax.swing.JTextField floatingPointTextField;
    private javax.swing.JLabel floatingPointValueLabel;
    private javax.swing.JLabel registerLabel0;
    private javax.swing.JLabel registerLabel1;
    private javax.swing.JTextField registerTextField0;
    private javax.swing.JTextField registerTextField1;
    private javax.swing.JButton writeFloatingPointValue;
    // End of variables declaration//GEN-END:variables
}
