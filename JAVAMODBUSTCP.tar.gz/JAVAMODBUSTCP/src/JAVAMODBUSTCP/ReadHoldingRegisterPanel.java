package JAVAMODBUSTCP;

import javax.swing.JTextField;

public class ReadHoldingRegisterPanel extends javax.swing.JPanel {

    private JTextField[] dataTextField;
    
    public ReadHoldingRegisterPanel() {
        initComponents();
        dataTextField = new JTextField[8];
        dataTextField[0] = this.jTextField1;
        dataTextField[1] = this.jTextField2;
        dataTextField[2] = this.jTextField3;
        dataTextField[3] = this.jTextField4;
        dataTextField[4] = this.jTextField5;
        dataTextField[5] = this.jTextField6;
        dataTextField[6] = this.jTextField7;
        dataTextField[7] = this.jTextField8;
        SetEnabled();
    }

    private void SetEnabled(){
        int numberEnabled = (int) numberSpinner.getValue();
        for (int index = 0; index < numberEnabled; index++) {
            dataTextField[index].setEnabled(true);
        }
        for (int index = numberEnabled; index < dataTextField.length; index++) {
            dataTextField[index].setEnabled(false);
        }
        
        if(dataTextField[1].isEnabled())
            floatTextField1.setEnabled(true);
        else
            floatTextField1.setEnabled(false);
        
        if(dataTextField[3].isEnabled())
            floatTextField2.setEnabled(true);
        else
            floatTextField2.setEnabled(false);
        
        if(dataTextField[5].isEnabled())
            floatTextField3.setEnabled(true);
        else
            floatTextField3.setEnabled(false);

        if(dataTextField[7].isEnabled())
            floatTextField4.setEnabled(true);
        else
            floatTextField4.setEnabled(false);        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        readHoldingRegister = new javax.swing.JButton();
        numberSpinner = new javax.swing.JSpinner();
        quantityLabel = new javax.swing.JLabel();
        addressTextBox = new javax.swing.JTextField();
        startingAddressLabel = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        readInputRegister = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        floatTextField2 = new javax.swing.JTextField();
        floatLabel = new javax.swing.JLabel();
        valueLabel = new javax.swing.JLabel();
        floatTextField3 = new javax.swing.JTextField();
        floatTextField4 = new javax.swing.JTextField();
        floatTextField1 = new javax.swing.JTextField();

        setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.gray, 5));
        setLayout(new java.awt.GridBagLayout());

        readHoldingRegister.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        readHoldingRegister.setText("READ HOLDING REGISTER: 03");
        readHoldingRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                readHoldingRegisterActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        add(readHoldingRegister, gridBagConstraints);

        numberSpinner.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        numberSpinner.setModel(new javax.swing.SpinnerNumberModel(1, 1, 8, 1));
        numberSpinner.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                numberSpinnerStateChanged(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.ipadx = 20;
        gridBagConstraints.ipady = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(numberSpinner, gridBagConstraints);

        quantityLabel.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        quantityLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        quantityLabel.setText("QUANTITY");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(quantityLabel, gridBagConstraints);

        addressTextBox.setColumns(1);
        addressTextBox.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        addressTextBox.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        addressTextBox.setText("1");
        addressTextBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.ipadx = 75;
        gridBagConstraints.ipady = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(addressTextBox, gridBagConstraints);

        startingAddressLabel.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        startingAddressLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        startingAddressLabel.setText("STARTING ADDRESS");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(startingAddressLabel, gridBagConstraints);

        jLabel18.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setText("1");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.ipadx = 10;
        add(jLabel18, gridBagConstraints);

        jLabel19.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel19.setText("2");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 7;
        gridBagConstraints.ipadx = 10;
        add(jLabel19, gridBagConstraints);

        jLabel20.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel20.setText("3");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.ipadx = 10;
        add(jLabel20, gridBagConstraints);

        jLabel21.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel21.setText("4");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 9;
        gridBagConstraints.ipadx = 10;
        add(jLabel21, gridBagConstraints);

        jLabel22.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel22.setText("5");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 10;
        gridBagConstraints.ipadx = 10;
        add(jLabel22, gridBagConstraints);

        jLabel23.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel23.setText("6");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 11;
        gridBagConstraints.ipadx = 10;
        add(jLabel23, gridBagConstraints);

        jLabel24.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel24.setText("7");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 12;
        gridBagConstraints.ipadx = 10;
        add(jLabel24, gridBagConstraints);

        jLabel25.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel25.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel25.setText("8");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 13;
        gridBagConstraints.ipadx = 10;
        add(jLabel25, gridBagConstraints);

        readInputRegister.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        readInputRegister.setText("READ INPUT REGISTER: 04");
        readInputRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                readInputRegisterActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        add(readInputRegister, gridBagConstraints);

        jTextField1.setEditable(false);
        jTextField1.setColumns(1);
        jTextField1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jTextField1.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextField1.setText(" ");
        jTextField1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.ipadx = 60;
        gridBagConstraints.ipady = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(jTextField1, gridBagConstraints);

        jTextField2.setEditable(false);
        jTextField2.setColumns(1);
        jTextField2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jTextField2.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextField2.setText(" ");
        jTextField2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 7;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.ipadx = 60;
        gridBagConstraints.ipady = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(jTextField2, gridBagConstraints);

        jTextField3.setEditable(false);
        jTextField3.setColumns(1);
        jTextField3.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jTextField3.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextField3.setText(" ");
        jTextField3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.ipadx = 60;
        gridBagConstraints.ipady = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(jTextField3, gridBagConstraints);

        jTextField4.setEditable(false);
        jTextField4.setColumns(1);
        jTextField4.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jTextField4.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextField4.setText(" ");
        jTextField4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 9;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.ipadx = 60;
        gridBagConstraints.ipady = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(jTextField4, gridBagConstraints);

        jTextField5.setEditable(false);
        jTextField5.setColumns(1);
        jTextField5.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jTextField5.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextField5.setText(" ");
        jTextField5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 10;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.ipadx = 60;
        gridBagConstraints.ipady = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(jTextField5, gridBagConstraints);

        jTextField6.setEditable(false);
        jTextField6.setColumns(1);
        jTextField6.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jTextField6.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextField6.setText(" ");
        jTextField6.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 11;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.ipadx = 60;
        gridBagConstraints.ipady = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(jTextField6, gridBagConstraints);

        jTextField7.setEditable(false);
        jTextField7.setColumns(1);
        jTextField7.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jTextField7.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextField7.setText(" ");
        jTextField7.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 12;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.ipadx = 60;
        gridBagConstraints.ipady = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(jTextField7, gridBagConstraints);

        jTextField8.setEditable(false);
        jTextField8.setColumns(1);
        jTextField8.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jTextField8.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextField8.setText(" ");
        jTextField8.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 13;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.ipadx = 60;
        gridBagConstraints.ipady = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(jTextField8, gridBagConstraints);

        floatTextField2.setEditable(false);
        floatTextField2.setColumns(1);
        floatTextField2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        floatTextField2.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        floatTextField2.setText(" ");
        floatTextField2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.ipadx = 60;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(floatTextField2, gridBagConstraints);

        floatLabel.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        floatLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        floatLabel.setText("FLOATING POINT");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(floatLabel, gridBagConstraints);

        valueLabel.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        valueLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        valueLabel.setText("EQUIVALENT");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(valueLabel, gridBagConstraints);

        floatTextField3.setEditable(false);
        floatTextField3.setColumns(1);
        floatTextField3.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        floatTextField3.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        floatTextField3.setText(" ");
        floatTextField3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 10;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.ipadx = 60;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(floatTextField3, gridBagConstraints);

        floatTextField4.setEditable(false);
        floatTextField4.setColumns(1);
        floatTextField4.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        floatTextField4.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        floatTextField4.setText(" ");
        floatTextField4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 12;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.ipadx = 60;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(floatTextField4, gridBagConstraints);

        floatTextField1.setEditable(false);
        floatTextField1.setColumns(1);
        floatTextField1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        floatTextField1.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        floatTextField1.setText(" ");
        floatTextField1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.ipadx = 60;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(floatTextField1, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents

    private void readHoldingRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_readHoldingRegisterActionPerformed
        Read(ModbusCommand.REGISTER_TYPE.HOLDING);
    }//GEN-LAST:event_readHoldingRegisterActionPerformed

    private void readInputRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_readInputRegisterActionPerformed
        Read(ModbusCommand.REGISTER_TYPE.INPUT);
    }//GEN-LAST:event_readInputRegisterActionPerformed

    private void numberSpinnerStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_numberSpinnerStateChanged
        SetEnabled();
    }//GEN-LAST:event_numberSpinnerStateChanged

    private void Read(ModbusCommand.REGISTER_TYPE functionCode) {
        Main.SetClientAddress();

        ModbusClient.Connect();
        int numberOfRegisters = (int) numberSpinner.getValue();

        byte[] data = ModbusCommand.ReadHoldingOrInputRegistor((short) Integer.parseInt(addressTextBox.getText()), (short) numberOfRegisters, functionCode);

        ModbusClient.Disconnect();

        short[] registers = new short[numberOfRegisters];

        short highByteIndex = 9;
        short lowByteIndex = 10;
        for (int index = 0; index < numberOfRegisters; index++) {
            registers[index] = (short) ((data[highByteIndex] << 8) | (data[lowByteIndex] & 0x00FF));
            highByteIndex += 2;
            lowByteIndex += 2;
        }
        for (int index = 0; index < numberOfRegisters; index++) {
            dataTextField[index].setText(Integer.toString(registers[index]));
        }

        if (dataTextField[1].isEnabled()) {
            floatTextField1.setText(String.format("%.4f", Float.intBitsToFloat((registers[1] << 16) | (registers[0] & 0xFFFF))));
        }
        if (dataTextField[3].isEnabled()) {
            floatTextField2.setText(String.format("%.3f", Float.intBitsToFloat((registers[3] << 16) | (registers[2] & 0xFFFF))));
        }
        if (dataTextField[5].isEnabled()) {
            floatTextField3.setText(String.format("%.3f", Float.intBitsToFloat((registers[5] << 16) | (registers[4] & 0xFFFF))));
        }
        if (dataTextField[7].isEnabled()) {
            floatTextField4.setText(String.format("%.3f", Float.intBitsToFloat((registers[7] << 16) | (registers[6] & 0xFFFF))));
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField addressTextBox;
    private javax.swing.JLabel floatLabel;
    private javax.swing.JTextField floatTextField1;
    private javax.swing.JTextField floatTextField2;
    private javax.swing.JTextField floatTextField3;
    private javax.swing.JTextField floatTextField4;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JSpinner numberSpinner;
    private javax.swing.JLabel quantityLabel;
    private javax.swing.JButton readHoldingRegister;
    private javax.swing.JButton readInputRegister;
    private javax.swing.JLabel startingAddressLabel;
    private javax.swing.JLabel valueLabel;
    // End of variables declaration//GEN-END:variables
}
