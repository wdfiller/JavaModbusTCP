package JAVAMODBUSTCP;

public class WriteSingleRegisterPanel extends javax.swing.JPanel {

    public WriteSingleRegisterPanel() {
        initComponents();
    }
    
    public void SetValue(int value) {
    }

    public short GetValue() {
        return Short.parseShort(this.registerValueTextBox.getText());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jLabel5 = new javax.swing.JLabel();
        addressTextBox = new javax.swing.JTextField();
        writeCoilButton = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        registerValueTextBox = new javax.swing.JTextField();

        setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.gray, 5));
        setPreferredSize(new java.awt.Dimension(50, 220));
        setLayout(new java.awt.GridBagLayout());

        jLabel5.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("REGISTER VALUE");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 10);
        add(jLabel5, gridBagConstraints);

        addressTextBox.setColumns(1);
        addressTextBox.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        addressTextBox.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        addressTextBox.setText("1");
        addressTextBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.ipadx = 75;
        gridBagConstraints.ipady = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 10);
        add(addressTextBox, gridBagConstraints);

        writeCoilButton.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        writeCoilButton.setText("WRITE SINGLE REGISTER: 06");
        writeCoilButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                writeCoilButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 10);
        add(writeCoilButton, gridBagConstraints);

        jLabel6.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("COIL ADDRESS");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 10);
        add(jLabel6, gridBagConstraints);

        registerValueTextBox.setColumns(1);
        registerValueTextBox.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        registerValueTextBox.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        registerValueTextBox.setText("0");
        registerValueTextBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.ipadx = 75;
        gridBagConstraints.ipady = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 10);
        add(registerValueTextBox, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents

    private void writeCoilButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_writeCoilButtonActionPerformed
        Main.SetClientAddress();

        ModbusClient.Connect();
        ModbusCommand.WriteSingleRegister((short) Integer.parseInt(addressTextBox.getText()), GetValue());
        ModbusClient.Disconnect();

    }//GEN-LAST:event_writeCoilButtonActionPerformed
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField addressTextBox;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JTextField registerValueTextBox;
    private javax.swing.JButton writeCoilButton;
    // End of variables declaration//GEN-END:variables
}
