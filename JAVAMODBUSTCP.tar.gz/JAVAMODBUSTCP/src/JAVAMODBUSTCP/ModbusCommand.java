package JAVAMODBUSTCP;

public class ModbusCommand {

    private static short transactionID = 0;
    private static final byte MBAPHEADERLENGTH = 7;
    public enum BOOLEAN_READ_TYPE{
        COIL,
        INPUT
    }
    public enum REGISTER_TYPE{
        HOLDING,
        INPUT
    } 

    //****************************************
    //Read input or coil
    //****************************************
    public static byte[] ReadInputOrCoil(short startingAddress, short number, BOOLEAN_READ_TYPE functionCode){
        byte requestFunctionCode;
        if(functionCode.equals(BOOLEAN_READ_TYPE.COIL))
            requestFunctionCode=1;
        else
            requestFunctionCode=2;
        startingAddress -= 1; //for zero based indexed Modbus
        byte[] message = new byte[MBAPHEADERLENGTH + 5];
        //MPAB HEADER
        ConfigureMBAPHeader(message, (byte) 6);
        //COMMAND
        message[7] = requestFunctionCode; //function code
        message[8] = (byte) (startingAddress >> 8); //address high byte
        message[9] = (byte) (startingAddress & 0xFF); //address low byte
        message[10] = (byte) (number >> 8); //quantity high byte
        message[11] = (byte) (number & 0xFF); //quantity low byte

        ModbusClient.Send(message);

        byte responseByteCount;

        if (number % 8 == 0) {
            responseByteCount = (byte) (number / 8);
        } else {
            responseByteCount = (byte) (1 + number / 8);
        }

        byte[] responseADU = ModbusClient.Receive((byte) (MBAPHEADERLENGTH + responseByteCount + 2));

        //if only two bytes are returned after the header then an exception code was sent
        if ((byte) responseADU[5] == (byte) (0x03)) {
            CheckForModbusExceptionCode(message, responseADU, requestFunctionCode);
        }

        byte[] registers = new byte[responseByteCount];

        for (int i = 0; i < responseByteCount; i++) {
            registers[i] = responseADU[MBAPHEADERLENGTH + 2 + i];
        }
        return registers;
    }

    //****************************************
    //Read holding registers or input registers
    //****************************************
    public static byte[] ReadHoldingOrInputRegistor(short startingAddress, short numberOfRegisters, REGISTER_TYPE code){
        //function code 3: read holding register
        //funcion code 4: read input register
        startingAddress -= 1; //for zero based indexed Modbus
        
        byte requestFunctionCode;
        if(code.equals(REGISTER_TYPE.HOLDING))
            requestFunctionCode = 3;
        else
            requestFunctionCode=4;

        byte[] message = new byte[MBAPHEADERLENGTH + 5];
        //MPAB HEADER
        ConfigureMBAPHeader(message, (byte) 6);
        //COMMAND
        message[7] = requestFunctionCode; //function code
        message[8] = (byte) (startingAddress >> 8); //address high byte
        message[9] = (byte) (startingAddress & 0xFF); //address low byte
        message[10] = (byte) (numberOfRegisters >> 8); //quantity high byte
        message[11] = (byte) (numberOfRegisters & 0xFF); //quantity low byte

        ModbusClient.Send(message);
        byte responseByteCount = (byte) (2 * numberOfRegisters);
        byte[] responseADU = ModbusClient.Receive((byte)(MBAPHEADERLENGTH + responseByteCount + 2));

        //if only two bytes are returned after the header then an exception code was sent
        if (responseADU[5] == (0x03)) {
            CheckForModbusExceptionCode(message, responseADU, requestFunctionCode);
        }
        return responseADU;
    }

    //****************************************
    //Write a single coil.  It returns true if the operation was successful
    //****************************************
    public static byte[] WriteSingleCoil(short address, boolean state){
        byte requestFunctionCode = 5;
        byte byteCount = 5;
        int messageLength = byteCount + MBAPHEADERLENGTH;
        address -= 1; //for zero based indexed Modbus
        byte[] message = new byte[messageLength];
        //MPAB HEADER
        ConfigureMBAPHeader(message, (byte) 6);
        //COMMAND
        message[7] = requestFunctionCode; //function code
        message[8] = (byte) (address >> 8); //address high byte
        message[9] = (byte) (address & 0xFF); //address low byte
        if (state) {
            message[10] = (byte) 0xFF; //output state
            message[11] = 0x00; //output state
        } else {
            message[10] = 0x00; //output state
            message[11] = 0x00; //output state
        }

        ModbusClient.Send(message);

        byte[] responseADU = ModbusClient.Receive((byte) messageLength);

        //if only two bytes are returned after the header then an exception code was sent
        if ((byte)responseADU[5] == (byte)(0x03)) {
           CheckForModbusExceptionCode(message, responseADU, requestFunctionCode);     
        }
        
        return responseADU;
    }

    //****************************************
    //Write multiple coils.
    //****************************************
    public static void WriteMultipleCoils(short address,  byte quantity, byte[] outputs){
        byte requestFunctionCode = 0xF;//decimal 15
        byte responseByteCount = 5;
        byte outputByteCount;
        
        if (quantity % 8 == 0) {
            outputByteCount = (byte) (quantity / 8);
        } else {
            outputByteCount = (byte) (1 + quantity / 8);
        }        
        
        int messageLength = MBAPHEADERLENGTH + 6 + outputByteCount;
        address -= 1; //for zero based indexed Modbus
        byte[] message = new byte[messageLength];
        //MPAB HEADER
        ConfigureMBAPHeader(message, (byte) (7+outputByteCount));
        //COMMAND
        message[7] = requestFunctionCode; //function code
        message[8] = (byte) (address >> 8); //address high byte
        message[9] = (byte) (address & 0xFF); //address low byte
        message[10] = (byte) (quantity >> 8); //quantity of outputs high byte
        message[11] = (byte) (quantity & 0xFF); //quantity of outputs low byte
        message[12] = (byte) outputByteCount; //byte count
        
        int j=0;
        for (int index = 13; index < 13 + outputByteCount; index++) {
            message[index] = (byte) (outputs[j]);
            j++;
        }

        ModbusClient.Send(message);

        byte[] responseADU = ModbusClient.Receive((byte) (MBAPHEADERLENGTH + responseByteCount));

        //if only two bytes are returned after the header then an exception code was sent
        if ((byte)responseADU[5] == (byte)(0x03)) {
           CheckForModbusExceptionCode(message, responseADU, requestFunctionCode);     
        }
    }
    
    //****************************************
    //Write a single register
    //****************************************
    public static boolean WriteSingleRegister(short address, short value){
        byte requestFunctionCode = 6;
        byte responseByteCount = 5;

        address -= 1; //for zero based indexed Modbus

        byte[] message = new byte[MBAPHEADERLENGTH + responseByteCount];
        //MPAB HEADER
        ConfigureMBAPHeader(message, (byte) 6);

        //COMMAND
        //function code
        message[7] = requestFunctionCode;
        message[8] = (byte) (address >> 8); //address high byte
        message[9] = (byte) (address & 0xFF); //address low byte
        message[10] = (byte) (value >> 8); //value high byte
        message[11] = (byte) (value & 0xFF); //value low byte

        ModbusClient.Send(message);

        byte[] responseADU = ModbusClient.Receive((byte) (MBAPHEADERLENGTH + responseByteCount));

        //if only two bytes are returned after the header then an exception code was sent
        if ((byte)responseADU[5] == (byte)(0x03)) {
           CheckForModbusExceptionCode(message, responseADU, requestFunctionCode);     
        }
        return true;
    }

    //****************************************
    //Write a multiple registers
    //****************************************
    public static boolean WriteMultipleRegister(short address, short[] value){
        byte requestFunctionCode = 0x10; //decimal 16
        byte registerByteCount = (byte) (2 * value.length); //2 bytes per short

        address -= 1; //for zero based indexed Modbus

        byte[] message = new byte[MBAPHEADERLENGTH + 6 + registerByteCount];
        //MPAB HEADER
        ConfigureMBAPHeader(message, (byte) (7 + registerByteCount));

        //COMMAND
        //function code
        message[7] = requestFunctionCode;
        //starting address
        message[8] = (byte) (address >> 8); //address high byte
        message[9] = (byte) (address & 0xFF); //address low byte
        //quantity of registers
        message[10] = (byte) (value.length >> 8); //value high byte
        message[11] = (byte) (value.length & 0xFF); //value low byte
        //byte count
        message[12] = (byte) registerByteCount;
        //register values

        int j = 0;
        for (int index = 13; index < message.length; index += 2) {
            message[index] = (byte) (value[j] >> 8); //value high byte
            message[index + 1] = (byte) (value[j] & 0xFF); //value low byte
            j++;
        }

        ModbusClient.Send(message);

        byte[] responseADU = ModbusClient.Receive((byte) (MBAPHEADERLENGTH + 5));

        //if only two bytes are returned after the header then an exception code was sent
        if ((byte)responseADU[5] == (byte)(0x03)) {
           CheckForModbusExceptionCode(message, responseADU, requestFunctionCode);     
        }
        
        return true;
    }

    //****************************************
    //Builds the header for all Modbus commands
    //****************************************
    private static void ConfigureMBAPHeader(byte[] message, byte length) {
        transactionID++;
        //MPAB HEADER
        message[0] = (byte) (transactionID >> 8); //transaction id high byte
        message[1] = (byte) (transactionID & 0xFF); //transaction id low byte
        message[2] = 0; //protocol identifier
        message[3] = 0; //protocol identifier
        message[4] = (byte) (length >> 8); //length high byte: byte count of the following fields, including the Unit Identifier and data fields
        message[5] = (byte) (length & 0xFF); //length low byte: byte count of the following fields, including the Unit Identifier and data fields
        message[6] = (byte) 255; //unit identifier or slave address
    }

    //****************************************
    //Lookup the modbus exception code
    //****************************************
    private static void CheckForModbusExceptionCode(byte[] message, byte[] response, byte requestFunctionCode){
        String errorMessage="";
        if ((byte)response[MBAPHEADERLENGTH] == (byte)(0x80 + requestFunctionCode)) {
            switch (response[MBAPHEADERLENGTH + 1]) {
                case 0x01 -> errorMessage="ILLEGAL FUNCTION";
                case 0x02 -> errorMessage="ILLEGAL DATA ADDRESS";
                case 0x03 -> errorMessage="ILLEGAL DATA VALUE";
                case 0x04 -> errorMessage="SLAVE DEVICE FAILURE";
                case 0x05 -> errorMessage="ACKNOWLEDGE";
                case 0x06 -> errorMessage="SLAVE DEVICE BUSY";
                case 0x07 -> errorMessage="MEMORY PARITY ERROR";
                case 0x0A -> errorMessage="GATEWAY PATH UNAVAILABLE";
                case 0x0B -> errorMessage="GATEWAY TARGET DEVICE FAILED TO RESPOND";
                default -> errorMessage="unknown";
            }
        }
        if ((message[0] != response[0]) || (message[1] != response[1])) {
            errorMessage="Invalid Transaction ID";
        }
        Main.SetException(errorMessage);
    }

    public static String GetReadableByteArray(byte[] byteArray) {
        StringBuilder message = new StringBuilder();
        for (int index = 0; index < byteArray.length; index++) {
            message.append(String.format("%02X", byteArray[index]));
            if(index < byteArray.length-1)
                message.append(":");
        }
        return message.toString();
    }
}
