package JAVAMODBUSTCP;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Enumeration;
import javax.swing.JOptionPane;

public class ModbusClient {

    private static String remoteIPAddress = "";
    private static String localIPAddress = "";
    private static int remotePortNumber;
    private static int localPortNumber=0;
    private static SocketChannel socketChannel;
    private static boolean bind;

    public static void SetRemoteIP(String address) {
        if (ValidInet4Address(address)) {
            remoteIPAddress = address;
        }
    }
    
    public static void SetLocalIP(String address) {
        if (ValidInet4Address(address)) {
            localIPAddress = address;
        }
    }
    public static void SetBound(boolean bound){
        bind = bound;
    }
    public static void SetRemotePortNumber(int port) {
        remotePortNumber = port;
    }

    public static void Send(byte[] message){
        Main.SetRequest(ModbusCommand.GetReadableByteArray(message));
        try {
            if(socketChannel.isConnected())
                socketChannel.write(ByteBuffer.wrap(message));
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    public static byte[] Receive(byte bytesToReceive) {
        byte[] message = new byte[bytesToReceive];
        try {
            if (socketChannel.isConnected()) {
                socketChannel.socket().setSoTimeout(1000);
                socketChannel.read(ByteBuffer.wrap(message));
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
        Main.SetResponse(ModbusCommand.GetReadableByteArray(message));
        return message;
    }

    public static void Connect() {
        try {            
            socketChannel = SocketChannel.open();
            if(bind)
                socketChannel.bind(new InetSocketAddress(Inet4Address.getByName(localIPAddress), localPortNumber));            
            socketChannel.socket().connect(new InetSocketAddress(remoteIPAddress, remotePortNumber), 1000);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    public static void Disconnect(){
        if (socketChannel != null && socketChannel.isConnected()) {
            try {
                socketChannel.close();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage());
            }
        }
    }

    public static void PrintNetworkInterfaceList() {
        try {
            for (Enumeration<NetworkInterface> e = NetworkInterface.getNetworkInterfaces(); e.hasMoreElements();) {
                NetworkInterface ni = e.nextElement();
                System.out.println("Index:" + ni.getIndex() + " Name:" + ni.getName() + " DisplayName:" + ni.getDisplayName());
            }
        } catch (SocketException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    public static boolean ValidInet4Address(String address) {
        String[] array = address.split("\\.");
        return ((array.length == 4) && ValidRange(array[0]) && ValidRange(array[1]) && ValidRange(array[2]) && ValidRange(array[2]));
    }

    public static boolean ValidRange(String value) {
        try {
            int intVal = Integer.parseInt(value);
            return (intVal >= 0) && (intVal <= 255);
        } catch (NumberFormatException ex) {
            return false;
        }
    }
}
