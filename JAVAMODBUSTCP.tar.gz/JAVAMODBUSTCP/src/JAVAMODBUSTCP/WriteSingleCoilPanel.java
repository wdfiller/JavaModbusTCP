package JAVAMODBUSTCP;

public class WriteSingleCoilPanel extends javax.swing.JPanel {

    public WriteSingleCoilPanel() {
        initComponents();
    }
    
    public void SetCoil(boolean state) {
        jRadioButton1.setSelected(state);
    }

    public boolean GetCoil() {
        return jRadioButton1.isSelected();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jLabel5 = new javax.swing.JLabel();
        addressTextBox = new javax.swing.JTextField();
        writeCoilButton = new javax.swing.JButton();
        jRadioButton1 = new javax.swing.JRadioButton();

        setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.gray, 5));
        setPreferredSize(new java.awt.Dimension(50, 220));
        setLayout(new java.awt.GridBagLayout());

        jLabel5.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("COIL ADDRESS");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 10);
        add(jLabel5, gridBagConstraints);

        addressTextBox.setColumns(1);
        addressTextBox.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        addressTextBox.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        addressTextBox.setText("1");
        addressTextBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.ipadx = 75;
        gridBagConstraints.ipady = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 10);
        add(addressTextBox, gridBagConstraints);

        writeCoilButton.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        writeCoilButton.setText("WRITE SINGLE COIL: 05");
        writeCoilButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                writeCoilButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 10);
        add(writeCoilButton, gridBagConstraints);

        jRadioButton1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jRadioButton1.setText("WRITE ON/OFF");
        jRadioButton1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jRadioButton1.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        add(jRadioButton1, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents

    private void writeCoilButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_writeCoilButtonActionPerformed
        Main.SetClientAddress();
        ModbusClient.Connect();
        ModbusCommand.WriteSingleCoil((short) Integer.parseInt(addressTextBox.getText()), GetCoil());
        ModbusClient.Disconnect();
    }//GEN-LAST:event_writeCoilButtonActionPerformed
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField addressTextBox;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JButton writeCoilButton;
    // End of variables declaration//GEN-END:variables
}
